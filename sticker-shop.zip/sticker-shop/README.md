# Наклейки на заказ

Две отдельные части:

| Что | Где | Как запускать |
|---|---|---|
| **Бот** | `bot.py` | PyCharm → ▶ |
| **Mini App** | папка `webapp/` | выложить на HTTPS (GitHub Pages) |

Telegram открывает мини-апп **только по HTTPS**. С `localhost` кнопка в боте не заработает — это ограничение Telegram, не бага кода.

---

## 1. Бот в PyCharm

1. Откройте папку `sticker-shop` в PyCharm (**File → Open**).
2. Создайте интерпретатор: **Settings → Python Interpreter → Add → Virtualenv**.
3. В Terminal:
   ```bash
   pip install -r requirements.txt
   ```
4. Напишите [@BotFather](https://t.me/BotFather) → `/newbot` → скопируйте токен.
5. Напишите [@userinfobot](https://t.me/userinfobot) → скопируйте свой ID.
6. В начале `bot.py` вставьте:
   ```python
   BOT_TOKEN = "123456:AAE...."
   ADMIN_IDS = [123456789]
   WEBAPP_URL = "https://ВАШ-ЛОГИН.github.io/sticker-shop/"
   ```
   `WEBAPP_URL` заполните после шага 2.
7. Откройте `bot.py` → ▶ **Run**.
8. В Telegram напишите боту `/start`.

Остановка — красный квадрат ■.

Если токен не вставлен, в консоли будет явная ошибка `BOT_TOKEN пустой` — так и должно быть.

---

## 2. Mini App (коротко)

Нужен публичный HTTPS. Самый простой путь — GitHub Pages.

1. Залейте папку `sticker-shop` на GitHub (в PyCharm: **VCS → Share Project on GitHub**).
2. На github.com: репозиторий → **Settings → Pages**.
3. Source: **Deploy from a branch**, Branch: `main`, Folder: **`/webapp`** → Save.
4. Через 1–2 минуты адрес будет:
   `https://ВАШ-ЛОГИН.github.io/sticker-shop/`
5. Вставьте его в `WEBAPP_URL` в `bot.py` (со слэшем на конце) и перезапустите бота.

Проверка: откройте этот адрес в обычном браузере — должен показаться конструктор наклеек.

Альтернативы хостинга: Netlify / Cloudflare Pages — просто перетащите папку `webapp`.

---

## 3. Как это работает вместе

1. Клиент жмёт в боте «🎨 Собрать наклейку».
2. Telegram открывает Mini App с GitHub Pages.
3. Клиент собирает наклейку и жмёт «Оформить заказ».
4. Mini App отправляет данные боту (`sendData`).
5. Бот пересчитывает цену сам, пишет заказ в `orders.sqlite3` и присылает его вам.

Админ (ваш ID): кнопки статусов у заказа, `/admin`, `/orders`, `/order 12`, `/export`.

---

## Если что-то не так

| Симптом | Что сделать |
|---|---|
| `BOT_TOKEN пустой` | вставьте токен в `bot.py` |
| `ModuleNotFoundError: aiogram` | `pip install -r requirements.txt`, проверьте интерпретатор |
| Нет кнопки «Собрать наклейку» | `WEBAPP_URL` должен начинаться с `https://` |
| Белый экран в мини-аппе | в Pages выбрана папка `/webapp`, адрес со `/` на конце |
| Заказ не приходит | Mini App открыт из кнопки бота, а не из обычного браузера |
