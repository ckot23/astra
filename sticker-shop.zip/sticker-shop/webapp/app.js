/* Mini App «Наклейки на заказ». Без сборщиков и зависимостей. */
(function () {
  "use strict";

  var tg = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;

  /* ---------- Прайс (зеркало bot/pricing.py) ---------- */

  var FILMS = [
    { id: "matte", name: "Матовая", desc: "Без бликов, универсальная", rate: 2.2 },
    { id: "gloss", name: "Глянцевая", desc: "Яркие цвета, легко моется", rate: 2.4 },
    { id: "transparent", name: "Прозрачная", desc: "Для стекла и витрин", rate: 2.8 },
    { id: "metallic", name: "Металлик", desc: "Зеркальный эффект", rate: 3.5 },
    { id: "reflective", name: "Светоотражающая", desc: "Видно в свете фар", rate: 4.2 }
  ];

  var DESIGNS = [
    { id: "own", name: "Свой файл", desc: "PNG, SVG, PDF, AI", mult: 1.0, setup: 0,
      hint: "Пришлёте файл в чат после заказа" },
    { id: "text", name: "Надпись", desc: "Слово или фраза", mult: 1.1, setup: 0,
      hint: "Напишите текст и желаемый шрифт" },
    { id: "logo", name: "Макет под ключ", desc: "Рисуем дизайн с нуля", mult: 1.25, setup: 1500,
      hint: "Опишите идею: что изобразить и в каком стиле" },
    { id: "catalog", name: "Из каталога", desc: "Готовые шаблоны", mult: 1.0, setup: 0,
      hint: "Напишите тему: космос, авто, аниме и т. д." }
  ];

  var COLORS = [
    { id: "black", name: "Чёрный", css: "#2c2c2b" },
    { id: "white", name: "Белый", css: "#ffffff" },
    { id: "red", name: "Красный", css: "#e5352b" },
    { id: "blue", name: "Синий", css: "#1b5fc1" },
    { id: "green", name: "Зелёный", css: "#2f8f4f" },
    { id: "yellow", name: "Жёлтый", css: "#f2c31b" },
    { id: "orange", name: "Оранжевый", css: "#ef7a1a" },
    { id: "silver", name: "Серебро", css: "linear-gradient(135deg,#e8e8e8,#a8a8a8 55%,#f2f2f2)" },
    { id: "gold", name: "Золото", css: "linear-gradient(135deg,#f5d47a,#c9922c 55%,#f7e3a1)" },
    { id: "fullcolor", name: "Полноцветная печать",
      css: "conic-gradient(from 210deg,#e5352b,#f2c31b,#2f8f4f,#1b5fc1,#8e44ad,#e5352b)" }
  ];

  var COLOR_MULT = { fullcolor: 1.3, gold: 1.15, silver: 1.15 };

  var SIZES = [
    { label: "5 × 5 см", w: 5, h: 5 },
    { label: "10 × 10 см", w: 10, h: 10 },
    { label: "20 × 20 см", w: 20, h: 20 },
    { label: "30 × 15 см", w: 30, h: 15 },
    { label: "1 × 1 м", w: 100, h: 100 },
    { label: "3 × 2 м", w: 300, h: 200 }
  ];

  var QUANTITIES = [1, 5, 10, 25, 50, 100];
  var TIERS = [[100, 0.6], [50, 0.68], [25, 0.75], [10, 0.82], [5, 0.9], [1, 1]];
  var MIN_ITEM_PRICE = 300;

  function byId(list, id) {
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return list[0];
  }

  function quantityMultiplier(qty) {
    for (var i = 0; i < TIERS.length; i++) if (qty >= TIERS[i][0]) return TIERS[i][1];
    return 1;
  }

  function calculate(s) {
    var film = byId(FILMS, s.film);
    var design = byId(DESIGNS, s.design);
    var area = s.width * s.height;
    var colorMult = COLOR_MULT[s.color] || 1;
    var rawUnit = area * film.rate * design.mult * colorMult;
    var unit = Math.max(MIN_ITEM_PRICE, Math.round(rawUnit / 10) * 10);
    var discount = quantityMultiplier(s.quantity);
    var total = Math.round(unit * s.quantity * discount / 10) * 10 + design.setup;
    return {
      unit: unit,
      setup: design.setup,
      discountPercent: Math.round((1 - discount) * 100),
      total: total
    };
  }

  function money(value) {
    return value.toLocaleString("ru-RU").replace(/\u00a0/g, " ") + " \u20bd";
  }

  /* ---------- Состояние ---------- */

  var state = {
    film: "matte",
    design: "own",
    color: "black",
    width: 10,
    height: 10,
    quantity: 10,
    comment: "",
    contact: ""
  };

  var el = {
    films: document.getElementById("films"),
    designs: document.getElementById("designs"),
    colors: document.getElementById("colors"),
    sizes: document.getElementById("sizes"),
    quantities: document.getElementById("quantities"),
    width: document.getElementById("width"),
    height: document.getElementById("height"),
    quantity: document.getElementById("quantity"),
    comment: document.getElementById("comment"),
    contact: document.getElementById("contact"),
    colorNote: document.getElementById("color-note"),
    sizeNote: document.getElementById("size-note"),
    qtyNote: document.getElementById("qty-note"),
    designHint: document.getElementById("design-hint-label"),
    summary: document.getElementById("summary-list"),
    priceValue: document.getElementById("price-value"),
    priceLabel: document.getElementById("price-label"),
    submit: document.getElementById("submit"),
    toast: document.getElementById("toast")
  };

  /* ---------- Рендер управления ---------- */

  function buildOptions(container, list, key) {
    list.forEach(function (item) {
      var button = document.createElement("button");
      button.type = "button";
      button.className = "option";
      button.setAttribute("role", "radio");
      button.dataset.id = item.id;

      var main = document.createElement("span");
      main.className = "option__main";
      var name = document.createElement("span");
      name.className = "option__name";
      name.textContent = item.name;
      var desc = document.createElement("span");
      desc.className = "option__desc";
      desc.textContent = item.desc;
      main.appendChild(name);
      main.appendChild(desc);

      var meta = document.createElement("span");
      meta.className = "option__meta";
      meta.textContent = key === "film"
        ? item.rate.toFixed(1) + " \u20bd/\u0441\u043c\u00b2"
        : (item.setup ? "+" + money(item.setup) : "\u0431\u0435\u0437 \u0434\u043e\u043f\u043b\u0430\u0442\u044b");
      button.appendChild(main);
      button.appendChild(meta);

      button.addEventListener("click", function () {
        state[key] = item.id;
        haptic();
        render();
      });
      container.appendChild(button);
    });
  }

  function buildColors() {
    COLORS.forEach(function (color) {
      var button = document.createElement("button");
      button.type = "button";
      button.className = "swatch";
      button.setAttribute("role", "radio");
      button.setAttribute("aria-label", color.name);
      button.title = color.name;
      button.dataset.id = color.id;

      var fill = document.createElement("span");
      fill.className = "swatch__fill";
      fill.style.background = color.css;
      if (color.id === "white") fill.style.boxShadow = "inset 0 0 0 1px rgba(0,0,0,.12)";
      button.appendChild(fill);

      button.addEventListener("click", function () {
        state.color = color.id;
        haptic();
        render();
      });
      el.colors.appendChild(button);
    });
  }

  function buildSizes() {
    SIZES.forEach(function (size) {
      var button = document.createElement("button");
      button.type = "button";
      button.className = "chip";
      button.setAttribute("role", "radio");
      button.textContent = size.label;
      button.dataset.w = size.w;
      button.dataset.h = size.h;
      button.addEventListener("click", function () {
        state.width = size.w;
        state.height = size.h;
        el.width.value = size.w;
        el.height.value = size.h;
        haptic();
        render();
      });
      el.sizes.appendChild(button);
    });
  }

  function buildQuantities() {
    QUANTITIES.forEach(function (qty) {
      var button = document.createElement("button");
      button.type = "button";
      button.className = "chip";
      button.textContent = qty + " \u0448\u0442";
      button.dataset.qty = qty;
      button.addEventListener("click", function () {
        state.quantity = qty;
        el.quantity.value = qty;
        haptic();
        render();
      });
      el.quantities.appendChild(button);
    });
  }

  /* ---------- Валидация ---------- */

  function clampNumber(value, min, max, fallback) {
    var parsed = parseFloat(String(value).replace(",", "."));
    if (!isFinite(parsed)) return fallback;
    return Math.min(max, Math.max(min, parsed));
  }

  function validate() {
    if (!(state.width >= 1 && state.width <= 500)) return "Ширина: от 1 до 500 см";
    if (!(state.height >= 1 && state.height <= 500)) return "Высота: от 1 до 500 см";
    if (!(state.quantity >= 1 && state.quantity <= 10000)) return "Тираж: от 1 до 10 000 шт";
    if (state.contact.trim().length < 4) return "Укажите контакт для связи";
    return null;
  }

  /* ---------- Рендер ---------- */

  function markSelected(container, selector, matcher) {
    var nodes = container.querySelectorAll(selector);
    for (var i = 0; i < nodes.length; i++) {
      nodes[i].setAttribute("aria-checked", matcher(nodes[i]) ? "true" : "false");
    }
  }

  function addRow(dl, term, value) {
    var dt = document.createElement("dt");
    dt.textContent = term;
    var dd = document.createElement("dd");
    dd.textContent = value;
    dl.appendChild(dt);
    dl.appendChild(dd);
  }

  function render() {
    markSelected(el.films, ".option", function (n) { return n.dataset.id === state.film; });
    markSelected(el.designs, ".option", function (n) { return n.dataset.id === state.design; });
    markSelected(el.colors, ".swatch", function (n) { return n.dataset.id === state.color; });
    markSelected(el.sizes, ".chip", function (n) {
      return parseFloat(n.dataset.w) === state.width && parseFloat(n.dataset.h) === state.height;
    });

    var qtyChips = el.quantities.querySelectorAll(".chip");
    for (var i = 0; i < qtyChips.length; i++) {
      qtyChips[i].setAttribute("aria-pressed",
        parseInt(qtyChips[i].dataset.qty, 10) === state.quantity ? "true" : "false");
    }

    var color = byId(COLORS, state.color);
    var extra = COLOR_MULT[state.color];
    el.colorNote.textContent = "Выбрано: " + color.name +
      (extra ? " \u00b7 +" + Math.round((extra - 1) * 100) + "% \u043a \u0446\u0435\u043d\u0435" : "");

    var design = byId(DESIGNS, state.design);
    el.designHint.textContent = design.hint;

    var area = state.width * state.height;
    el.sizeNote.textContent = "Площадь одной наклейки: " +
      area.toLocaleString("ru-RU") + " \u0441\u043c\u00b2";

    var price = calculate(state);

    if (price.discountPercent > 0) {
      el.qtyNote.textContent = "Скидка за тираж: \u2212" + price.discountPercent + "%";
      el.qtyNote.className = "note note--accent";
    } else {
      el.qtyNote.textContent = "От 5 шт — скидка 10%, от 100 шт — 40%";
      el.qtyNote.className = "note";
    }

    el.summary.innerHTML = "";
    addRow(el.summary, "Материал", byId(FILMS, state.film).name);
    addRow(el.summary, "Дизайн", design.name);
    addRow(el.summary, "Цвет", color.name);
    addRow(el.summary, "Размер", state.width + " \u00d7 " + state.height + " \u0441\u043c");
    addRow(el.summary, "Тираж", state.quantity + " \u0448\u0442");
    addRow(el.summary, "Цена за шт", money(price.unit));
    if (price.discountPercent > 0) {
      addRow(el.summary, "Скидка", "\u2212" + price.discountPercent + "%");
    }
    if (price.setup > 0) addRow(el.summary, "Разработка макета", money(price.setup));
    addRow(el.summary, "Итого", money(price.total));

    el.priceValue.textContent = money(price.total);
    el.priceLabel.textContent = state.quantity + " \u0448\u0442 \u00b7 \u0438\u0442\u043e\u0433\u043e";

    var error = validate();
    el.submit.disabled = Boolean(error);

    if (tg && tg.MainButton) {
      tg.MainButton.setText(error ? error : "Оформить за " + money(price.total));
      if (error) tg.MainButton.disable(); else tg.MainButton.enable();
      tg.MainButton.show();
    }
  }

  /* ---------- События ---------- */

  el.width.addEventListener("input", function () {
    state.width = clampNumber(el.width.value, 1, 500, state.width);
    render();
  });
  el.height.addEventListener("input", function () {
    state.height = clampNumber(el.height.value, 1, 500, state.height);
    render();
  });
  el.quantity.addEventListener("input", function () {
    state.quantity = Math.round(clampNumber(el.quantity.value, 1, 10000, state.quantity));
    render();
  });
  el.comment.addEventListener("input", function () { state.comment = el.comment.value; });
  el.contact.addEventListener("input", function () {
    state.contact = el.contact.value;
    render();
  });

  document.getElementById("qty-minus").addEventListener("click", function () {
    state.quantity = Math.max(1, state.quantity - 1);
    el.quantity.value = state.quantity;
    haptic();
    render();
  });
  document.getElementById("qty-plus").addEventListener("click", function () {
    state.quantity = Math.min(10000, state.quantity + 1);
    el.quantity.value = state.quantity;
    haptic();
    render();
  });

  el.submit.addEventListener("click", submit);

  function haptic() {
    if (tg && tg.HapticFeedback) tg.HapticFeedback.selectionChanged();
  }

  function toast(message) {
    el.toast.textContent = message;
    el.toast.hidden = false;
    window.clearTimeout(toast._timer);
    toast._timer = window.setTimeout(function () { el.toast.hidden = true; }, 3200);
  }

  function submit() {
    var error = validate();
    if (error) {
      toast(error);
      if (tg && tg.HapticFeedback) tg.HapticFeedback.notificationOccurred("error");
      return;
    }

    var price = calculate(state);
    var payload = {
      v: 1,
      film: state.film,
      design: state.design,
      color: state.color,
      w: state.width,
      h: state.height,
      qty: state.quantity,
      comment: state.comment.slice(0, 600),
      contact: state.contact.slice(0, 120),
      client_total: price.total
    };

    if (tg && typeof tg.sendData === "function") {
      tg.sendData(JSON.stringify(payload));
      return;
    }

    // Запасной путь: открыто в обычном браузере или через кнопку меню.
    fetch("api/order", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(Object.assign({ init_data: tg ? tg.initData : "" }, payload))
    })
      .then(function (response) { return response.json().catch(function () { return {}; }); })
      .then(function (data) {
        if (data && data.ok) {
          toast("Заявка \u2116" + data.order_id + " принята");
        } else {
          toast((data && data.error) || "Не удалось отправить заказ");
        }
      })
      .catch(function () {
        toast("Нет связи с сервером. Откройте мини-приложение из бота.");
      });
  }

  /* ---------- Старт ---------- */

  buildOptions(el.films, FILMS, "film");
  buildOptions(el.designs, DESIGNS, "design");
  buildColors();
  buildSizes();
  buildQuantities();

  if (tg) {
    tg.ready();
    tg.expand();
    if (tg.MainButton) {
      document.body.classList.add("has-mainbutton");
      tg.MainButton.onClick(submit);
    }
    if (tg.initDataUnsafe && tg.initDataUnsafe.user && tg.initDataUnsafe.user.username) {
      state.contact = "@" + tg.initDataUnsafe.user.username;
      el.contact.value = state.contact;
    }
  }

  render();
})();
